


/**
 * Arquivo: auth.js
 * Descrição: Gerenciamento de autenticação com a API do Google Sign-In
 */

// 1. Configurações Iniciais
// Substitua pelo seu Client ID obtido no Google Cloud Console
const GOOGLE_CLIENT_ID = "SEU_CLIENT_ID_AQUI.apps.googleusercontent.com";

/**
 * Função para inicializar o script do Google e renderizar o botão.
 * Deve ser chamada assim que a página carregar (ex: window.onload)
 */
function inicializarAutenticacao() {
    if (typeof google !== 'undefined') {
        google.accounts.id.initialize({
            client_id: GOOGLE_CLIENT_ID,
            callback: lidarComRespostaLogin // Função que processa o token
        });

        // Renderiza o botão oficial do Google no elemento com id="btnGoogle"
        google.accounts.id.renderButton(
            document.getElementById("btnGoogle"),
            { 
                theme: "filled_blue", 
                size: "large", 
                type: "standard",
                shape: "rectangular"
            }
        );

        // Opcional: Mostra o prompt de "One Tap" (login automático flutuante)
        google.accounts.id.prompt(); 
    } else {
        console.error("O script de autenticação do Google não foi carregado corretamente.");
    }
}

/**
 * Callback executado após o usuário se autenticar com sucesso no Google
 * @param {Object} response - Objeto de resposta contendo o JWT (JSON Web Token)
 */
function lidarComRespostaLogin(response) {
    // O credential é um token JWT criptografado que contém os dados do usuário
    const tokenCriptografado = response.credential;
    
    // Decodifica o token para ler as informações básicas do perfil
    const dadosUsuario = decodificarJWT(tokenCriptografado);
    
    console.log("Usuário autenticado com sucesso:", dadosUsuario);
    
    // Armazena temporariamente na sessão do navegador
    sessionStorage.setItem("usuario_prime", JSON.stringify(dadosUsuario));

    // --- PREPARAÇÃO PARA O FUTURO BANCO DE DADOS ---
    // Quando você tiver seu back-end/banco pronto, você ativará a função abaixo:
    // enviarParaOBancoDeDados(tokenCriptografado);

    // Redireciona o usuário para a página principal da wiki ou área logada
    alert(`Bem-vindo, ${dadosUsuario.name}!`);
    // window.location.href = "dashboard.html";
}

/**
 * Função utilitária para decodificar o token JWT retornado pelo Google
 * @param {string} token - Token JWT recebido
 * @returns {Object} Dados do perfil do usuário descodificados
 */
function decodificarJWT(token) {
    const base64Url = token.split('.')[1];
    const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
    const jsonPayload = decodeURIComponent(window.atob(base64).split('').map(function(c) {
        return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
    }).join(''));

    return JSON.parse(jsonPayload);
}

/**
 * Esboço da função futura para salvar no banco de dados
 * @param {string} token 
 */
async function enviarParaOBancoDeDados(token) {
    try {
        // Exemplo de requisição para sua futura API/Back-end
        const resposta = await fetch("https://sua-api.com/api/auth/google", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({ idToken: token })
        });
        
        const resultado = await resposta.json();
        console.log("Salvo no banco de dados com sucesso:", resultado);
    } catch (erro) {
        console.error("Erro ao enviar dados para o servidor:", erro);
    }
}

// Exporta as funções caso use módulos ES6, ou deixa global se usar script comum
window.inicializarAutenticacao = inicializarAutenticacao;