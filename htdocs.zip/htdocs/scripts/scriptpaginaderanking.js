﻿document.addEventListener('DOMContentLoaded', async function () {
    const body = document.getElementById('rankingBody');
    if (!body) return;

    const apiBasePath = window.location.pathname.includes('/paginas/') ? './api' : 'paginas/api';
    const rankingUrl = `${apiBasePath}/ranking.php`;

    console.log('[RANKING] script loaded on', window.location.pathname);
    console.log('[RANKING] fetching ranking from', rankingUrl);

    function setRankingState(key, value) {
        console.log('[RANKING STATE]', key, value);
        localStorage.setItem(key, JSON.stringify(value));
    }

    try {
        const response = await fetch(rankingUrl);
        const result = await response.json();
        console.log('[RANKING] response', result);
        setRankingState('primeRankingResult', result);

        body.innerHTML = '';
        if (!result.success || !Array.isArray(result.data) || result.data.length === 0) {
            body.innerHTML = '<tr><td colspan="3" class="empty-state">Por enquanto n há usuarios</td></tr>';
            setRankingState('primeRankingStatus', 'empty');
            return;
        }

        setRankingState('primeRankingStatus', 'loaded');
        result.data.forEach((item, index) => {
            const row = document.createElement('tr');
            row.innerHTML = `<td>${index + 1}</td><td>${item.nome}</td><td>${parseFloat(item.tempo).toFixed(3)}</td>`;
            body.appendChild(row);
        });
    } catch (error) {
        console.error('[RANKING] error', error);
        localStorage.setItem('primeRankingError', JSON.stringify({ message: error.message || 'fetch error', time: new Date().toISOString() }));
        body.innerHTML = '<tr><td colspan="3" class="empty-state">Não foi possível carregar o ranking</td></tr>';
    }
});
