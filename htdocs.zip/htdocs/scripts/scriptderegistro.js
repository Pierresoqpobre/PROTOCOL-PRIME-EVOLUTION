﻿document.addEventListener('DOMContentLoaded', function () {
    const form = document.getElementById('registerForm');
    const message = document.getElementById('registerMessage');

    console.log('[REGISTER] script loaded on', window.location.pathname);

    if (!form) return;

    const apiBasePath = window.location.pathname.includes('/paginas/') ? './api' : 'paginas/api';

    function setRegisterState(key, value) {
        console.log('[REGISTER STATE]', key, value);
        localStorage.setItem(key, JSON.stringify(value));
    }

    async function postRegister(url, formData) {
        console.log('[REGISTER] posting to', url);
        const response = await fetch(url, { method: 'POST', body: formData });
        const result = await response.json();
        console.log('[REGISTER] response from', url, result);
        return result;
    }

    form.addEventListener('submit', async function (event) {
        event.preventDefault();
        message.textContent = '';

        const formData = new FormData(form);
        const primaryUrl = `${apiBasePath}/register.php`;
        const fallbackUrl = `${apiBasePath}/register_simple.php`;

        const attempt = {
            time: new Date().toISOString(),
            page: window.location.pathname,
            nome: formData.get('nome')?.toString() || '',
            email: formData.get('email')?.toString() || ''
        };
        setRegisterState('primeLastRegisterAttempt', attempt);

        async function showSuccess(messageText) {
            setRegisterState('primeLastRegisterResult', { success: true, message: messageText });
            message.style.color = '#a8ff6f';
            message.textContent = messageText;
            setTimeout(() => {
                window.location.href = 'login.html';
            }, 1200);
        }

        try {
            let result = await postRegister(primaryUrl, formData);
            setRegisterState('primeRegisterPrimaryResult', result);
            if (result.success) {
                await showSuccess('Conta criada com sucesso. Redirecionando para login...');
                return;
            }

            if (/conexão|banco|servidor|mysql|502|504/i.test(result.message || '')) {
                setRegisterState('primeLastRegisterFallback', true);
                const fallbackResult = await postRegister(fallbackUrl, formData);
                setRegisterState('primeRegisterFallbackResult', fallbackResult);
                if (fallbackResult.success) {
                    await showSuccess('Conta criada com sucesso (modo simples). Redirecionando para login...');
                    return;
                }
                setRegisterState('primeLastRegisterResult', fallbackResult);
                message.style.color = '#ffbb6e';
                message.textContent = fallbackResult.message || 'Erro ao criar conta.';
                return;
            }

            setRegisterState('primeLastRegisterResult', result);
            message.style.color = '#ffbb6e';
            message.textContent = result.message || 'Erro ao criar conta.';
        } catch (error) {
            console.error('[REGISTER] error', error);
            setRegisterState('primeLastRegisterError', error.message || 'fetch error');
            try {
                const fallbackResult = await postRegister(fallbackUrl, formData);
                setRegisterState('primeRegisterFallbackResult', fallbackResult);
                if (fallbackResult.success) {
                    await showSuccess('Conta criada com sucesso (modo simples). Redirecionando para login...');
                    return;
                }
                setRegisterState('primeLastRegisterResult', fallbackResult);
                message.style.color = '#ffbb6e';
                message.textContent = fallbackResult.message || 'Erro ao criar conta.';
            } catch (fallbackError) {
                console.error('[REGISTER] fallback error', fallbackError);
                setRegisterState('primeLastRegisterError', fallbackError.message || 'fallback fetch error');
                message.style.color = '#ffbb6e';
                message.textContent = 'Falha ao conectar com o servidor.';
            }
        }
    });
});
