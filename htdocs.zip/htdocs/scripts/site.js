﻿const pageLinks = [
    { title: 'Início', icon: '🏠', href: '/index.html' },
    { title: 'Login', icon: '🔐', href: '/paginas/login.html' },
    { title: 'Registrar', icon: '✍️', href: '/paginas/registrar.html' },
    { title: 'Ranking', icon: '🏁', href: '/paginas/ranking.html' },
    { title: 'Download', icon: '⬇️', href: '/paginas/download.html' }
];

function setPrimeState(key, value) {
    console.log('[PRIME STATE]', key, value);
    localStorage.setItem(key, JSON.stringify(value));
}

function getPrimeState(key, fallback = null) {
    try {
        const value = localStorage.getItem(key);
        return value === null ? fallback : JSON.parse(value);
    } catch (error) {
        console.error('[PRIME STATE] invalid JSON for', key, error);
        return fallback;
    }
}

setPrimeState('primeActivePage', window.location.pathname);

function resolveLink(href) {
    if (window.location.pathname.includes('/paginas/')) {
        if (href === 'index.html') return '../index.html';
        if (href.startsWith('paginas/')) return href.replace('paginas/', '');
        return href;
    }
    return href;
}

function buildSidebar() {
    const sidebarNav = document.getElementById('sidebarNav');
    if (!sidebarNav) return;

    console.log('[SITE] Building sidebar for', window.location.pathname);
    const currentFile = window.location.pathname.split('/').pop();
    sidebarNav.innerHTML = '';

    pageLinks.forEach(item => {
        const link = document.createElement('a');
        link.href = resolveLink(item.href);
        link.innerHTML = `<span>${item.icon}</span><span>${item.title}</span>`;
        if (currentFile === item.href.split('/').pop() || (currentFile === '' && item.href === 'index.html')) {
            link.classList.add('active');
        }
        sidebarNav.appendChild(link);
    });
}

function openSidebar() {
    console.log('[SITE] Sidebar open');
    document.getElementById('sidebar')?.classList.add('open');
    document.getElementById('sidebarOverlay')?.classList.add('visible');
    setPrimeState('primeSidebarOpen', true);
}

function closeSidebar() {
    console.log('[SITE] Sidebar close');
    document.getElementById('sidebar')?.classList.remove('open');
    document.getElementById('sidebarOverlay')?.classList.remove('visible');
    setPrimeState('primeSidebarOpen', false);
}

function applyTheme(theme) {
    const isLight = theme === 'light';
    console.log('[SITE] Applying theme', theme);
    document.body.classList.toggle('theme-light', isLight);
    setPrimeState('primeTheme', theme);

    const icon = document.getElementById('themeIcon');
    const text = document.getElementById('themeText');
    if (icon) {
        const basePath = window.location.pathname.includes('/paginas/') ? '../' : '';
        icon.src = basePath + 'imagens/background/' + (isLight ? 'sol.png' : 'lua.png');
    }
    if (text) {
        text.textContent = isLight ? 'Claro' : 'Escuro';
    }
}

function getLoggedUser() {
    try {
        return JSON.parse(localStorage.getItem('primeUser') || 'null');
    } catch {
        return null;
    }
}

function clearLoggedUser() {
    localStorage.removeItem('primeUser');
}

function renderUserStatus() {
    const user = getLoggedUser();
    console.log('[SITE] renderUserStatus user=', user);
    const header = document.querySelector('.main-header');
    const sidebar = document.querySelector('.sidebar');
    if (!header) return;

    const existingHeader = document.getElementById('userStatusHeader');
    existingHeader?.remove();

    const statusDiv = document.createElement('div');
    statusDiv.id = 'userStatusHeader';
    statusDiv.className = 'user-status';
    if (user) {
        statusDiv.textContent = `Bem Vindo, ${user.nome}!`;
        setPrimeState('primeProfileVisible', true);
        setPrimeState('primeUser', user);
    } else {
        statusDiv.textContent = 'Faça o login por favor';
        setPrimeState('primeProfileVisible', false);
    }
    header.appendChild(statusDiv);

    if (sidebar) {
        const existingSidebar = document.getElementById('userStatusSidebar');
        existingSidebar?.remove();
        const sidebarStatus = document.createElement('div');
        sidebarStatus.id = 'userStatusSidebar';
        sidebarStatus.className = 'sidebar-user-status';
        sidebarStatus.textContent = user ? `Bem Vindo, ${user.nome}!` : 'Faça o login por favor';
        
        const sidebarNav = sidebar.querySelector('.sidebar-nav');
        if (sidebarNav) {
            sidebarNav.insertAdjacentElement('beforebegin', sidebarStatus);
        }
    }
}

function renderThemeButtonInSidebar() {
    const sidebar = document.querySelector('.sidebar');
    if (!sidebar) return;

    const existingThemeButton = document.getElementById('sidebarThemeToggle');
    existingThemeButton?.remove();

    const button = document.createElement('button');
    button.id = 'sidebarThemeToggle';
    button.className = 'sidebar-theme-button';
    button.type = 'button';
    
    const currentTheme = getPrimeState('primeTheme', 'dark');
    button.innerHTML = `<img id="sidebarThemeIcon" src="" alt="Tema" /><span id="sidebarThemeText">Escuro</span>`;
    
    const basePath = window.location.pathname.includes('/paginas/') ? '../' : '';
    const icon = button.querySelector('#sidebarThemeIcon');
    icon.src = basePath + 'imagens/background/' + (currentTheme === 'light' ? 'sol.png' : 'lua.png');
    button.querySelector('#sidebarThemeText').textContent = currentTheme === 'light' ? 'Claro' : 'Escuro';
    
    const sidebarFooter = sidebar.querySelector('.sidebar-footer');
    if (sidebarFooter) {
        sidebarFooter.insertAdjacentElement('beforebegin', button);
    }

    button.addEventListener('click', event => {
        event.stopPropagation();
        toggleTheme();
        renderThemeButtonInSidebar();
    });
}

function renderProfileButton() {
    const user = getLoggedUser();
    console.log('[SITE] renderProfileButton user=', user);
    const header = document.querySelector('.main-header');
    if (!header) return;

    const existingButton = document.getElementById('profileButton');
    const existingMenu = document.getElementById('profileMenu');
    existingButton?.remove();
    existingMenu?.remove();

    if (!user) {
        setPrimeState('primeProfileVisible', false);
        return;
    }

    setPrimeState('primeProfileVisible', true);
    setPrimeState('primeUser', user);

    const button = document.createElement('button');
    button.id = 'profileButton';
    button.className = 'profile-button';
    button.type = 'button';
    button.innerHTML = `<span>${user.nome}</span><span class="profile-arrow">▾</span>`;

    const themeToggle = document.getElementById('themeToggle');
    if (themeToggle) {
        themeToggle.insertAdjacentElement('afterend', button);
    } else {
        header.appendChild(button);
    }

    const menu = document.createElement('div');
    menu.id = 'profileMenu';
    menu.className = 'profile-menu';
    menu.innerHTML = `
        <div class="profile-card">
            <strong>${user.nome}</strong>
            <span>${user.email}</span>
        </div>
        <button type="button" id="logoutButton" class="profile-logout">Sair</button>
    `;
    header.appendChild(menu);

    button.addEventListener('click', event => {
        event.stopPropagation();
        menu.classList.toggle('visible');
    });

    menu.querySelector('#logoutButton')?.addEventListener('click', () => {
        clearLoggedUser();
        menu.classList.remove('visible');
        button.remove();
        menu.remove();
        window.location.reload();
    });

    document.addEventListener('click', event => {
        if (!header.contains(event.target)) {
            menu.classList.remove('visible');
        }
    });
}

function toggleTheme() {
    const current = localStorage.getItem('primeTheme') || 'dark';
    applyTheme(current === 'dark' ? 'light' : 'dark');
}

window.addEventListener('DOMContentLoaded', () => {
    buildSidebar();

    document.getElementById('sidebarToggle')?.addEventListener('click', openSidebar);
    document.getElementById('sidebarClose')?.addEventListener('click', closeSidebar);
    document.getElementById('sidebarOverlay')?.addEventListener('click', closeSidebar);
    
    const themeToggle = document.getElementById('themeToggle');
    if (themeToggle) {
        themeToggle.style.display = 'none';
        themeToggle.removeEventListener('click', toggleTheme);
    }

    document.addEventListener('keydown', event => {
        if (event.key === 'Escape') closeSidebar();
    });

    const storedTheme = getPrimeState('primeTheme', 'dark');
    applyTheme(storedTheme);
    renderUserStatus();
    renderThemeButtonInSidebar();
    renderProfileButton();
    console.log('[SITE] Page initialized, state=', {
        page: window.location.pathname,
        theme: storedTheme,
        sidebarOpen: getPrimeState('primeSidebarOpen', false),
        loggedUser: getPrimeState('primeUser', null)
    });
});
