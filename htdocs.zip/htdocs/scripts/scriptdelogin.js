﻿document.addEventListener('DOMContentLoaded', function () {
    const form = document.getElementById('loginForm');
    const message = document.getElementById('loginMessage');

    console.log('[LOGIN] script loaded on', window.location.pathname);

    if (!form) return;

    const apiBasePath = window.location.pathname.includes('/paginas/') ? './api' : 'paginas/api';

    function setLoginState(key, value) {
        console.log('[LOGIN STATE]', key, value);
        localStorage.setItem(key, JSON.stringify(value));
    }

    async function postLogin(url, formData) {
        console.log('[LOGIN] posting to', url);
        const response = await fetch(url, { method: 'POST', body: formData });
        const result = await response.json();
        console.log('[LOGIN] response from', url, result);
        return result;
    }

    form.addEventListener('submit', async function (event) {
        event.preventDefault();
        message.textContent = '';

        const formData = new FormData(form);
        const primaryUrl = `${apiBasePath}/login.php`;
        const fallbackUrl = `${apiBasePath}/login_simple.php`;

        const attempt = {
            time: new Date().toISOString(),
            page: window.location.pathname,
            identifier: formData.get('identifier')?.toString() || '',
            apiPrimary: primaryUrl,
            apiFallback: fallbackUrl
        };
        setLoginState('primeLastLoginAttempt', attempt);

        try {
            let result = await postLogin(primaryUrl, formData);
            if (!result.success && /conexão|banco|servidor/i.test(result.message || '')) {
                result = await postLogin(fallbackUrl, formData);
                setLoginState('primeLastLoginFallback', true);
            }

            setLoginState('primeLastLoginResult', result);

            if (result.success) {
                localStorage.setItem('primeUser', JSON.stringify(result.user));
                setLoginState('primeLoggedIn', true);
                message.style.color = '#a8ff6f';
                message.textContent = 'Login efetuado com sucesso. Redirecionando...';
                setTimeout(() => {
                    window.location.href = '../index.html';
                }, 1000);
            } else {
                setLoginState('primeLoggedIn', false);
                message.style.color = '#ffbb6e';
                message.textContent = result.message || 'Erro de login. Verifique seus dados.';
            }
        } catch (error) {
            setLoginState('primeLastLoginError', error.message || 'fetch error');
            try {
                const fallbackResult = await postLogin(fallbackUrl, formData);
                setLoginState('primeLastLoginResult', fallbackResult);
                if (fallbackResult.success) {
                    localStorage.setItem('primeUser', JSON.stringify(fallbackResult.user));
                    setLoginState('primeLoggedIn', true);
                    message.style.color = '#a8ff6f';
                    message.textContent = 'Login efetuado com sucesso (modo simples). Redirecionando...';
                    setTimeout(() => {
                        window.location.href = '../index.html';
                    }, 1000);
                    return;
                }
                setLoginState('primeLoggedIn', false);
                message.style.color = '#ffbb6e';
                message.textContent = fallbackResult.message || 'Erro de login.';
            } catch (fallbackError) {
                setLoginState('primeLastLoginError', fallbackError.message || 'fallback fetch error');
                message.style.color = '#ffbb6e';
                message.textContent = 'Falha ao conectar com o servidor.';
                console.error(fallbackError);
            }
            console.error(error);
        }
    });
});
