<?php
header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Método não permitido.']);
    exit;
}

$nome = trim($_POST['nome'] ?? '');
$email = trim($_POST['email'] ?? '');
$senha = trim($_POST['senha'] ?? '');

if (strlen($nome) < 3 || strlen($email) < 5 || strlen($senha) < 6) {
    echo json_encode(['success' => false, 'message' => 'Por favor preencha todos os campos corretamente.']);
    exit;
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo json_encode(['success' => false, 'message' => 'Email inválido.']);
    exit;
}

$dataFile = __DIR__ . '/users.json';
if (!file_exists($dataFile)) {
    file_put_contents($dataFile, json_encode([]));
}

$fp = fopen($dataFile, 'c+');
if (!$fp) {
    echo json_encode(['success' => false, 'message' => 'Erro ao acessar arquivo de usuários.']);
    exit;
}
flock($fp, LOCK_EX);
$contents = stream_get_contents($fp);
rewind($fp);
$users = json_decode($contents, true);
if (!is_array($users)) $users = [];

// verifica duplicados
foreach ($users as $u) {
    if (strcasecmp($u['nome'] ?? '', $nome) === 0 || strcasecmp($u['email'] ?? '', $email) === 0) {
        flock($fp, LOCK_UN);
        fclose($fp);
        echo json_encode(['success' => false, 'message' => 'Nome ou email já estão em uso.']);
        exit;
    }
}

$senhaPlain = $senha;
$nextId = 1;
if (!empty($users)) {
    $ids = array_column($users, 'id');
    $nextId = (int)max($ids) + 1;
}

$users[] = ['id' => $nextId, 'nome' => $nome, 'email' => $email, 'senha' => $senhaPlain];

ftruncate($fp, 0);
rewind($fp);
fwrite($fp, json_encode($users, JSON_UNESCAPED_UNICODE));
fflush($fp);
flock($fp, LOCK_UN);
fclose($fp);

echo json_encode(['success' => true, 'message' => 'Conta criada com sucesso (modo simples).']);
exit;
