﻿<?php
require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Método não permitido.']);
    exit;
}

$identifier = trim($_POST['identifier'] ?? '');
$senha = trim($_POST['senha'] ?? '');

if (strlen($identifier) === 0 || strlen($senha) === 0) {
    echo json_encode(['success' => false, 'message' => 'Preencha usuário/email e senha.']);
    exit;
}

$stmt = $mysqli->prepare('SELECT id, nome, email, senha FROM usuarios WHERE nome = ? OR email = ? LIMIT 1');
$stmt->bind_param('ss', $identifier, $identifier);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

if (!$user || (!password_verify($senha, $user['senha']) && $senha !== $user['senha'])) {
    echo json_encode(['success' => false, 'message' => 'Usuário ou senha incorretos.']);
    exit;
}

echo json_encode(['success' => true, 'user' => ['id' => $user['id'], 'nome' => $user['nome'], 'email' => $user['email']]]);
$stmt->close();
$mysqli->close();
