﻿<?php
require_once 'config.php';

$query = "
    SELECT u.nome, t.tempo
    FROM tempos t
    INNER JOIN usuarios u ON u.id = t.usuario_id
    ORDER BY t.tempo ASC
    LIMIT 100
";
$result = $mysqli->query($query);
if (!$result) {
    echo json_encode(['success' => false, 'message' => 'Erro ao consultar ranking.']);
    exit;
}

$data = [];
while ($row = $result->fetch_assoc()) {
    $data[] = [
        'nome' => $row['nome'],
        'tempo' => $row['tempo']
    ];
}

if (empty($data)) {
    echo json_encode(['success' => false, 'message' => 'Por enquanto n há usuarios']);
} else {
    echo json_encode(['success' => true, 'data' => $data]);
}
$result->free();
$mysqli->close();
