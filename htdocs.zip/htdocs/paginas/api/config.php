﻿<?php
header('Content-Type: application/json; charset=utf-8');
$DB_HOST = 'sql303.infinityfree.com';
$DB_USER = 'if0_42579232';
$DB_PASS = 'primeprotocol23';
$DB_NAME = 'if0_42579232_bancoprime';
$DB_PORT = 3306;

/*
    Configuração MySQL para InfinityFree:
    Host: sql303.infinityfree.com
    Usuário: if0_42579232
    Senha: primeprotocol23
    Banco: if0_42579232_bancoprime
    Porta: 3306
*/

$mysqli = new mysqli($DB_HOST, $DB_USER, $DB_PASS, $DB_NAME, $DB_PORT);
if ($mysqli->connect_errno) {
    http_response_code(500);
    $error = sprintf('Falha ao conectar ao MySQL: (%s) %s', $mysqli->connect_errno, $mysqli->connect_error);
    echo json_encode(['success' => false, 'message' => 'Erro de conexão ao banco de dados.', 'error' => $error]);
    exit;
}
$mysqli->set_charset('utf8mb4');
