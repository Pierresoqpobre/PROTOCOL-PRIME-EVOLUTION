<?php
header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Método não permitido.']);
    exit;
}

$identifier = trim($_POST['identifier'] ?? '');
$senha = trim($_POST['senha'] ?? '');

if (strlen($identifier) === 0 || strlen($senha) === 0) {
    echo json_encode(['success' => false, 'message' => 'Preencha usuário/email e senha.']);
    exit;
}

$dataFile = __DIR__ . '/users.json';
if (!file_exists($dataFile)) {
    echo json_encode(['success' => false, 'message' => 'Nenhum usuário registrado ainda.' ]);
    exit;
}

$contents = file_get_contents($dataFile);
$users = json_decode($contents, true);
if (!is_array($users)) $users = [];

$found = null;
foreach ($users as $u) {
    if (strcasecmp($u['nome'] ?? '', $identifier) === 0 || strcasecmp($u['email'] ?? '', $identifier) === 0) {
        $found = $u;
        break;
    }
}

if (!$found || (!password_verify($senha, $found['senha']) && $senha !== $found['senha'])) {
    echo json_encode(['success' => false, 'message' => 'Usuário ou senha incorretos.']);
    exit;
}

echo json_encode(['success' => true, 'user' => ['id' => $found['id'], 'nome' => $found['nome'], 'email' => $found['email']]]);
exit;
