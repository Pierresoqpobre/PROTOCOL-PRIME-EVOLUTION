﻿<?php
require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Método não permitido.']);
    exit;
}

$nome = trim($_POST['nome'] ?? '');
$email = trim($_POST['email'] ?? '');
$senha = trim($_POST['senha'] ?? '');

if (strlen($nome) < 3 || strlen($email) < 5 || strlen($senha) < 6) {
    echo json_encode(['success' => false, 'message' => 'Por favor preencha todos os campos corretamente.']);
    exit;
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo json_encode(['success' => false, 'message' => 'Email inválido.']);
    exit;
}

$senhaPlain = $senha;
$stmt = $mysqli->prepare('INSERT INTO usuarios (nome, email, senha) VALUES (?, ?, ?)');
if (!$stmt) {
    echo json_encode(['success' => false, 'message' => 'Erro interno no servidor.']);
    exit;
}
$stmt->bind_param('sss', $nome, $email, $senhaPlain);
if ($stmt->execute()) {
    echo json_encode(['success' => true, 'message' => 'Conta criada com sucesso.']);
} else {
    $error = $stmt->error;
    if (strpos($error, 'Duplicate') !== false || strpos($error, 'duplicate') !== false) {
        echo json_encode(['success' => false, 'message' => 'Nome ou email já estão em uso.']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Erro ao criar conta.']);
    }
}
$stmt->close();
$mysqli->close();
